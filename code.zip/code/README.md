# CZT: Calibrated Zero-day Triage

Code and results for the paper **"Calibrated Zero-Day Attack Detection and Whittle-Index Alert Triage under Leakage-Averse Evaluation"** (manuscript submitted to the *International Journal of Intelligent Engineering and Systems*).

CZT evaluates thirteen zero-day attack detectors under leakage-averse protocols and passes their calibrated scores to a simulated security operations centre (SOC), where alerts are ordered by a closed-form Whittle-type index tuned with NSGA-III.

![CZT workflow](figures/fig01_workflow.png)

## Main results

| Finding | Value |
|---|---|
| Duplicated or label-conflicting records removed from UNSW-NB15 | 41.3% (257,673 to 151,239) |
| Unseen-family AUROC of the leading group (XGBoost, LightGBM, DNN, CZT-Hybrid) | 0.957 to 0.961 |
| CZT-Hybrid mean rank / median zero-day detection rate (9 hold-out folds) | 2.67 / 0.828 |
| Detection of the hardest unseen family at 1% FPR (every detector) | about 10% or less |
| Captured zero-day value at 20% SOC overload, best baseline vs tuned index | 0.569 vs 0.670 |
| Mean zero-day waiting time, best baseline vs tuned index | 30.2 vs 7.0 minutes |

## Quick start

```bash
git clone <this repository>
cd czt-zero-day-triage
pip install -r requirements.txt
python -m analysis.make_all          # rebuild figures/ and tables/ from the stored results
```

`analysis.make_all` uses only the files in `results/`. Two figures need extra inputs and are skipped with a message if those are missing: `s01_data_characterisation` needs the datasets, and `fig05_permutation_importance` needs `results/e2_fold0_models.pkl`, which is created by `python -m experiments.exp_unsw fh` or `python -m experiments.retrain_fold0`.

## Full reproduction

```bash
python scripts/download_data.py      # UNSW-NB15 and NSL-KDD into data/, with SHA-256 checks
bash run_all.sh                      # all experiments, then figures and tables
```

All commands are run from the repository root. The reported runs used Python 3.11 on two CPU cores with 7 GB of memory and no GPU; the complete pipeline takes about three to four hours. Seeds are fixed in every script, and small numerical differences can arise between library versions.

| Step | Command | Output |
|---|---|---|
| P2 family hold-out (9 folds, 13 detectors) | `python -m experiments.exp_unsw fh` | `results/e2_fh.json`, `results/e2_scores.npz` |
| P1 i.i.d. cross-validation | `python -m experiments.exp_unsw iid` | `results/e1_iid.json` |
| Effect of de-duplication | `python -m experiments.exp_dedup_effect` | `results/e1b_dedup_effect.json` |
| Latency and footprint | `python -m experiments.exp_latency` | `results/e6_latency.json` |
| SOC triage and NSGA-III tuning | `python -m experiments.exp_triage` | `results/e7_triage.json`, `results/e7_nsga3.json` |
| P3 unseen NSL-KDD attack types | `python -m experiments.exp_kdd novel` | `results/e3_kdd_novel.json` |
| P4 cross-dataset transfer | `python -m experiments.exp_kdd transfer` | `results/e4_transfer.json` |
| Figures and tables | `python -m analysis.make_all` | `figures/`, `tables/` |

## Repository layout

```
zdt/            data loading and cleaning, detectors, metrics, SOC simulator, score storage
experiments/    one script per experiment (run with python -m experiments.<name>)
analysis/       figures and tables (make_all.py runs everything)
results/        stored outputs of all experiments (JSON and a compressed score archive)
figures/        paper figures (fig01 to fig10) and supplementary figures (s01 to s13)
tables/         paper tables (T4 to T10) and supplementary tables (s_table_*)
scripts/        dataset download with checksum verification
data/           place for the datasets (not stored in the repository)
```

| Module | Content |
|---|---|
| `zdt/data.py` | loading, removal of duplicates and label conflicts, feature encoding, 18-feature shared schema |
| `zdt/models.py` | 12 detectors, B-ProtoMeta, the calibrated hybrid and Platt scaling |
| `zdt/metrics.py` | expected calibration error, reliability curves, operating-point metrics, frozen threshold |
| `zdt/triage.py` | alert generation, discrete-event SOC simulator, Whittle-type index, outcome measures |
| `zdt/io.py` | compressed storage of per-fold detector scores |

## Paper figures and tables

| Paper item | File |
|---|---|
| Figure 1 workflow | `figures/fig01_workflow.png` |
| Figure 2 family hold-out per family | `figures/fig02_family_holdout.png` |
| Figure 3 optimism gap | `figures/fig03_optimism_gap.png` |
| Figure 4 critical-difference diagram | `figures/fig04_critical_difference.png` |
| Figure 5 permutation importance | `figures/fig05_permutation_importance.png` |
| Figure 6 unseen NSL-KDD types | `figures/fig06_nsl_kdd_unseen.png` |
| Figure 7 cross-dataset transfer | `figures/fig07_transfer.png` |
| Figure 8 reliability diagrams | `figures/fig08_calibration.png` |
| Figure 9 triage versus load | `figures/fig09_triage_load.png` |
| Figure 10 detector versus triage outcome | `figures/fig10_detector_triage_link.png` |
| Tables 4 to 10 | `tables/T4_p1.md` to `tables/T10_ablation.md` |

## Note on the original project data

An earlier version of this project was configured for CICAPT-IIoT 2024 and CyberSOCEval. Their raw files were not available, and the loaders silently generated synthetic stand-in data. No result from those stand-ins is used here; all results come from the public UNSW-NB15 and NSL-KDD files.

## Datasets

Please cite the dataset authors.

- N. Moustafa and J. Slay, "UNSW-NB15: A Comprehensive Data Set for Network Intrusion Detection Systems (UNSW-NB15 Network Data Set)", In: Proc. of the 2015 Military Communications and Information Systems Conference, pp. 1-6, 2015.
- M. Tavallaee, E. Bagheri, W. Lu, and A. A. Ghorbani, "A Detailed Analysis of the KDD CUP 99 Data Set", In: Proc. of the 2009 IEEE Symposium on Computational Intelligence for Security and Defense Applications, pp. 1-6, 2009.

## Citation

If you use this code, please cite the paper (full reference to be added after publication):

> Calibrated Zero-Day Attack Detection and Whittle-Index Alert Triage under Leakage-Averse Evaluation. Manuscript submitted to the International Journal of Intelligent Engineering and Systems, 2026.

## Licence

MIT, see `LICENSE`.
