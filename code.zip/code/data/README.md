# Data

The datasets are not stored in this repository. Run `python scripts/download_data.py`
from the repository root to download them into this folder and check their SHA-256 sums.

| File | Dataset | Official source |
|---|---|---|
| `UNSW_NB15_training-set.csv`, `UNSW_NB15_testing-set.csv` | UNSW-NB15 (partitioned release, 257,673 records) | https://research.unsw.edu.au/projects/unsw-nb15-dataset |
| `KDDTrain+.txt`, `KDDTest+.txt` | NSL-KDD | https://www.unb.ca/cic/datasets/nsl.html |

Please cite the dataset authors when you use these files (see the main README).
