"""Regenerate every table and figure of the paper and its supplement.

Run from the repository root:
    python -m analysis.make_all

Figures that need the raw datasets (s01) or the retrained fold-0 models
(fig05) are skipped with a message when those inputs are missing."""
import os
import runpy
from analysis import analyze as A
from analysis import paper_figures as P

os.makedirs("figures", exist_ok=True)
os.makedirs("tables", exist_ok=True)


def optional(fn, *args, need=()):
    missing = [p for p in need if not os.path.exists(p)]
    if missing:
        print(f"skipped {args[0]}: missing {', '.join(missing)}")
        return
    fn(*args)


# main paper figures (numbered as in the manuscript)
runpy.run_module("analysis.fig_workflow", run_name="__main__")             # Figure 1
mean, sd, _ = A.e1_tables("s_table_p1_full", "s02_iid_heatmap")           # Table 4 source, Figure S2
A.e2_table("s_table_p2_full")                                               # Table 5 source
A.e2_heatmap("fig02_family_holdout")                                        # Figure 2
A.gap_figure("fig03_optimism_gap", mean)                                    # Figure 3
A.cd_diagram("fig04_critical_difference", "s_table_wilcoxon")              # Figure 4
optional(A.importance_figure, "fig05_permutation_importance",
         need=("results/e2_fold0_models.pkl", "data/UNSW_NB15_training-set.csv"))  # Figure 5
A.e3("s_table_p3_full", "fig06_nsl_kdd_unseen")                             # Figure 6
A.e4("s_table_p4_full", "fig07_transfer")                                   # Figure 7
P.calib_row()                                                               # Figure 8
P.triage_row()                                                              # Figure 9
P.detector_link()                                                           # Figure 10
# supplementary figures
optional(A.fig_data, "s01_data_characterisation", need=("data/UNSW_NB15_training-set.csv", "data/KDDTrain+.txt"))
A.roc_pr_figure("s03_roc_pr")
A.e6("s_table_cost", "s04_latency")
A.calib_figure("s07_calibration_detail", "s_table_calibration")
A.e7("s_table_triage", "s_table_ablation", "s12_triage_load_detail", "s06_nsga3_fronts",
     "s05_staffing_halflife", "s13_ablation_detail")
runpy.run_module("analysis.supp_figures", run_name="__main__")              # s08 to s11
runpy.run_module("analysis.paper_tables", run_name="__main__")              # Tables 4 to 10
print("all figures and tables written to figures/ and tables/")
