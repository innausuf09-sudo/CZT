#!/usr/bin/env bash
# Full reproduction on CPU (about 3 to 4 hours on two cores). Run from the repository root.
set -e
python scripts/download_data.py
python -m experiments.exp_unsw fh        # P2 family hold-out  -> results/e2_*.json/.npz
python -m experiments.exp_unsw iid       # P1 i.i.d. CV        -> results/e1_*.json
python -m experiments.exp_dedup_effect   # cleaning effect     -> results/e1b_dedup_effect.json
python -m experiments.exp_latency        # cost                -> results/e6_latency.json
python -m experiments.exp_triage         # SOC triage, NSGA-III-> results/e7_*.json
python -m experiments.exp_kdd novel      # P3 NSL-KDD          -> results/e3_kdd_novel.json
python -m experiments.exp_kdd transfer   # P4 transfer         -> results/e4_transfer.json
python -m analysis.make_all              # figures/ and tables/
