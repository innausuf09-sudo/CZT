Place the NetFlow v3 CSV files here (see ../README.md). They are not stored in the repository.
