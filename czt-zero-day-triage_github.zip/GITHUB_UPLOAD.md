# Putting the CZT code on GitHub and getting a Zenodo DOI

## Which folder to publish

- `czt-zero-day-triage/` in this zip is the clean, GitHub-ready repository: code, stored results, figures,
  tables, README, licence, `CITATION.cff`, `.zenodo.json` and data instructions (no datasets).
- The revision experiments you ran in VS Code (`catalogue.py`, the tuned baselines, `e8_*` results and anything
  added later) exist only on your computer in `czt-revision/code/`. The repository you release must match the
  revised paper, so merge them before the release. In VS Code, tell Claude:

  > Copy CITATION.cff, .zenodo.json, .gitignore, data/nfv3/README.md and scripts/sample_nfv3.py from
  > czt-zero-day-triage/ into czt-revision/code/, merge the README changes, add every revision script and result
  > to the README tables, check that `python -m analysis.make_all` runs, and make sure no dataset files are included.

## Before uploading

1. Fill in the placeholders in `CITATION.cff` and `.zenodo.json`: author names, affiliations and ORCID iDs
   (delete the `orcid` lines if an author has none; Zenodo rejects the placeholder).
2. Replace `[username]` in `CITATION.cff` with your GitHub user name.
3. Make sure no file larger than 100 MB and no dataset CSV is in the folder.

## Upload to GitHub

The repository has more than 100 files, which is above the limit for one drag-and-drop upload on the GitHub
website, so use GitHub Desktop or the command line.

**GitHub Desktop**
1. Create an empty public repository named `czt-zero-day-triage` on github.com (no README, no licence; they are
   already in the folder).
2. In GitHub Desktop: File, Add local repository, choose the folder, create the repository when asked, commit
   all files, then Publish repository.

**Command line** (from inside the folder)
```
git init
git add .
git commit -m "CZT code and results for the IJIES revision"
git branch -M main
git remote add origin https://github.com/<username>/czt-zero-day-triage.git
git push -u origin main
```

## Get the DOI from Zenodo

1. Sign in at https://zenodo.org with your GitHub account.
2. In Zenodo's GitHub settings, switch on archiving for `czt-zero-day-triage`.
3. On GitHub, create a release: Releases, Draft a new release, tag `v1.0.0`, title "Code for the revised
   IJIES submission", Publish.
4. Zenodo archives that release within a few minutes and shows its DOI on the Zenodo upload page.

## After the DOI exists

Send the repository URL and the DOI to the revision session. They go into the Data Availability section, the
response letter (Reviewer 1, point 9) and the README citation. If the code changes after review, make a new
release (`v1.1.0`); Zenodo gives it a new version DOI under the same concept DOI.
